package com.phuchoccode.CommonnService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommonnServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommonnServiceApplication.class, args);
	}

}
